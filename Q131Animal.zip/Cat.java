class dog extends Animal {
  private int age;

  public Cat(String name, String age) {
    super(name); this.age = age;
  }
  public void bark() {System.out.println("냐옹");}

}